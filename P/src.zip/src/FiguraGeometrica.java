
public abstract class FiguraGeometrica {

    public abstract boolean verificacao(SegmentoReta seg);
    public abstract String stringToPrint(SegmentoReta seg);

}

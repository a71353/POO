public class Planeador {


//objetos - população.
}

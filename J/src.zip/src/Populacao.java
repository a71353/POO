import java.util.*;

public class Populacao {
    private ArrayList<Trajetoria> trajetorias;
    public Populacao (int n, int [] traj, Ponto inicial, Ponto fim) {
        trajetorias = new ArrayList<>();
        Random generator = new Random(0);
        for (int i = 0; i < n; i++) {
            ArrayList<Ponto> pontos = new ArrayList<>();
            for (int j = 0; j < traj[i]; j++) {
                int x = generator.nextInt(100);
                int y = generator.nextInt(100);
                Ponto p1 = new Ponto(x, y);
                pontos.add(p1);
            }
            pontos.add(0,inicial);
            pontos.add(fim);
            trajetorias.add(new Trajetoria(pontos));
        }
    }

    public ArrayList<Trajetoria> trajetorias(){
        return trajetorias;
    }

    public void orden(List<FiguraGeometrica> fig){
        Random generator = new Random(0);
        ArrayList<Trajetoria> trajord = new ArrayList<>();
        for(int i = 0; i < trajetorias.size(); i++){
            int random = generator.nextInt(0,trajetorias.size());
            int random2 = generator.nextInt(0, trajetorias.size());
            Trajetoria traj1 = trajetorias.get(random);
            Trajetoria traj2 = trajetorias.get(random2);
            if(traj1.avaluation(fig) >= traj2.avaluation(fig)){
                trajord.add(0,traj1);
            }
            else {
                trajord.add(0,traj2);
            }
        }
        this.trajetorias = trajord;
    }

    /**
     *
     * @return retorna o "\n"
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < trajetorias.size(); i++) {
            sb.append(trajetorias.get(i).toString());
            if (i != trajetorias.size() - 1) {
                sb.append("\n"); // Adiciona uma quebra de linha após cada trajetória, exceto a última
            }
        }
        return sb.toString();
    }
}

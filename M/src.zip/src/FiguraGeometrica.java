public abstract class FiguraGeometrica{

        public FiguraGeometrica(String s){}

        public abstract boolean intercecao(Trajetoria trajetoria);

        public abstract void verifica();


}
